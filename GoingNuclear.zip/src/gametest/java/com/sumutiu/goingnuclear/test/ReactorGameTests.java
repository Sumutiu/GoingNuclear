package com.sumutiu.goingnuclear.test;

import com.sumutiu.goingnuclear.config.NuclearConfig;
import com.sumutiu.goingnuclear.fluid.FluidHandler;
import com.sumutiu.goingnuclear.fluid.FluidType;
import com.sumutiu.goingnuclear.fluid.PipeNetwork;
import com.sumutiu.goingnuclear.fluid.PipeNetworks;
import com.sumutiu.goingnuclear.machine.BackupGeneratorBlockEntity;
import com.sumutiu.goingnuclear.machine.BatteryBankBlock;
import com.sumutiu.goingnuclear.machine.BatteryBankBlockEntity;
import com.sumutiu.goingnuclear.machine.CheckValveBlock;
import com.sumutiu.goingnuclear.machine.CheckValveBlockEntity;
import com.sumutiu.goingnuclear.machine.CirculationPumpBlock;
import com.sumutiu.goingnuclear.machine.CirculationPumpBlockEntity;
import com.sumutiu.goingnuclear.machine.CondenserBlockEntity;
import com.sumutiu.goingnuclear.machine.ElectricLampBlockEntity;
import com.sumutiu.goingnuclear.machine.ExpansionTankBlockEntity;
import com.sumutiu.goingnuclear.machine.EnrichmentCentrifugeBlock;
import com.sumutiu.goingnuclear.machine.EnrichmentCentrifugeBlockEntity;
import com.sumutiu.goingnuclear.machine.FluidPipeBlock;
import com.sumutiu.goingnuclear.machine.HeatExchangerBlock;
import com.sumutiu.goingnuclear.machine.HeatExchangerBlockEntity;
import com.sumutiu.goingnuclear.machine.SteamDumpValveBlock;
import com.sumutiu.goingnuclear.machine.SteamDumpValveBlockEntity;
import com.sumutiu.goingnuclear.machine.SteamTurbineBlockEntity;
import com.sumutiu.goingnuclear.machine.WaterOutletBlock;
import com.sumutiu.goingnuclear.machine.WaterOutletBlockEntity;
import com.sumutiu.goingnuclear.machine.WaterPumpBlock;
import com.sumutiu.goingnuclear.machine.WaterPumpBlockEntity;
import com.sumutiu.goingnuclear.power.ElectricConnectable;
import com.sumutiu.goingnuclear.power.PowerGrid;
import com.sumutiu.goingnuclear.power.PowerNetwork;
import com.sumutiu.goingnuclear.reactor.ControlRodChannelBlock;
import com.sumutiu.goingnuclear.reactor.FuelChannelBlock;
import com.sumutiu.goingnuclear.reactor.FuelChannelBlockEntity;
import com.sumutiu.goingnuclear.reactor.FuelRods;
import com.sumutiu.goingnuclear.reactor.ReactorControllerBlockEntity;
import com.sumutiu.goingnuclear.reactor.Xenon;
import com.sumutiu.goingnuclear.registry.ModBlocks;
import com.sumutiu.goingnuclear.registry.ModItems;
import com.sumutiu.goingnuclear.util.RadiationHandler;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import java.util.List;
import java.util.Locale;

/**
 * Automated in-game tests. Run them with {@code gradlew runGameTest}: a test server starts, builds small
 * reactors, runs them and reports which checks passed (also written to build/run/gameTest).
 * <p>
 * Every test builds the same dry 5x5x5 reactor from the README: casing shell from (1,1,1) to (5,5,5),
 * controller in the south wall, two ports, and on the middle layer five fuel channels (redstone rods)
 * with four control rod channels between them.
 */
public class ReactorGameTests {
    private static final BlockPos CONTROLLER = new BlockPos(3, 3, 5);
    private static final BlockPos CENTER_FUEL = new BlockPos(3, 3, 3);
    private static final List<BlockPos> FUEL = List.of(new BlockPos(2, 3, 2), new BlockPos(4, 3, 2), CENTER_FUEL,
            new BlockPos(2, 3, 4), new BlockPos(4, 3, 4));
    private static final List<BlockPos> CONTROL = List.of(new BlockPos(3, 3, 2), new BlockPos(2, 3, 3), new BlockPos(4, 3, 3),
            new BlockPos(3, 3, 4));

    // ---------------------------------------------------------------- tests

    @GameTest(maxTicks = 100)
    public void reactorForms(GameTestHelper helper) {
        buildReactor(helper);
        helper.runAfterDelay(40, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            helper.assertTrue(controller.isFormed(), "Reactor did not form: " + controller.status().getString());
            helper.assertTrue(controller.fuelChannels() == 5, "Expected 5 fuel channels, found " + controller.fuelChannels());
            helper.assertTrue(controller.controlRodsInstalled() == 4, "Expected 4 control rods, found " + controller.controlRodsInstalled());
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 100)
    public void coreMapSeesEveryChannel(GameTestHelper helper) {
        // The control box sits in the south wall, so the core map looks north into the core.
        buildReactor(helper);
        helper.runAfterDelay(40, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            helper.assertTrue(controller.isFormed(), "Reactor did not form: " + controller.status().getString());
            List<ReactorControllerBlockEntity.CoreCell> cells = controller.coreCells();
            long fuel = cells.stream().filter(ReactorControllerBlockEntity.CoreCell::isFuel).count();
            long control = cells.size() - fuel;
            helper.assertTrue(fuel == 5 && control == 4, "The map should see 5 fuel and 4 control channels (" + fuel + " / " + control + ")");
            helper.assertTrue(cells.stream().filter(ReactorControllerBlockEntity.CoreCell::isFuel).allMatch(cell -> cell.fuelLeft() > 0.99),
                    "Fresh rods should show as full");
            helper.assertTrue(controller.viewDirection() == Direction.NORTH, "Seen from the south wall, the map should look north ("
                    + controller.viewDirection().getName() + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 20)
    public void enrichedFuelHasMorePowerFromTheSameEnergy(GameTestHelper helper) {
        for (int[] pair : new int[][]{{FuelRods.REDSTONE, FuelRods.ENRICHED_REDSTONE}, {FuelRods.GLOWSTONE, FuelRods.ENRICHED_GLOWSTONE}}) {
            double ratio = FuelRods.basePower(pair[1]) / FuelRods.basePower(pair[0]);
            helper.assertTrue(ratio > 1.0, "Enriched " + FuelRods.name(pair[0]) + "s should give more power (" + format(ratio) + "x)");
            double energy = FuelRods.energy(pair[1]) / FuelRods.energy(pair[0]);
            helper.assertTrue(Math.abs(energy - NuclearConfig.get().enrichedEnergyFactor) < 1.0e-9,
                    "Enriched " + FuelRods.name(pair[0]) + "s should hold " + NuclearConfig.get().enrichedEnergyFactor + "x the energy (" + format(energy) + ")");
            helper.assertTrue(FuelRods.neutronFactor(pair[1]) == FuelRods.neutronFactor(pair[0]), "Enriching should not change the neutron factor");
        }
        helper.assertTrue(FuelRods.isSpent(FuelRods.tierOf(new ItemStack(ModItems.DEPLETED_REDSTONE_FUEL_ROD))), "Depleted redstone rods are spent");
        helper.assertTrue(!FuelRods.isActive(FuelRods.tierOf(new ItemStack(ModItems.DEPLETED_FUEL_ROD))), "Depleted rods have no fuel");
        helper.succeed();
    }

    @GameTest(maxTicks = 600)
    public void spentRodsDepleteIntoTheirOwnKind(GameTestHelper helper) {
        // A redstone rod and an enriched redstone rod with almost no fuel left: the first burns down into a depleted
        // redstone rod (it can be enriched), the enriched one into a plain depleted rod (it cannot).
        buildReactor(helper);
        BlockPos plain = FUEL.get(0);
        setNearlySpent(helper, plain, ModItems.REDSTONE_FUEL_ROD);
        setNearlySpent(helper, CENTER_FUEL, ModItems.ENRICHED_REDSTONE_FUEL_ROD);
        helper.runAfterDelay(40, () -> start(helper, 0.0));
        helper.runAfterDelay(500, () -> {
            helper.assertTrue(rodIn(helper, plain).is(ModItems.DEPLETED_REDSTONE_FUEL_ROD),
                    "A spent redstone rod should become a Depleted Redstone Fuel Rod (" + rodIn(helper, plain).getHoverName().getString() + ")");
            helper.assertTrue(rodIn(helper, CENTER_FUEL).is(ModItems.DEPLETED_FUEL_ROD),
                    "A spent enriched rod should become a Depleted Fuel Rod (" + rodIn(helper, CENTER_FUEL).getHoverName().getString() + ")");
            helper.assertTrue(rodIn(helper, FUEL.get(1)).is(ModItems.REDSTONE_FUEL_ROD), "Fresh rods should still be burning");
            helper.assertTrue(controller(helper).countSpent() == 2, "The core should count two spent rods (" + controller(helper).countSpent() + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 200)
    public void centrifugeEnrichesOnlyOnce(GameTestHelper helper) {
        // Centrifuge facing north, a backup generator at its back. Quicker and lighter than normal for the test.
        NuclearConfig config = NuclearConfig.get();
        int ticks = config.centrifugeTicks;
        double power = config.centrifugePower;
        config.centrifugeTicks = 40;
        config.centrifugePower = 50.0;
        BlockPos machine = new BlockPos(2, 1, 2);
        BlockPos generator = machine.south();
        helper.setBlock(machine, ModBlocks.ENRICHMENT_CENTRIFUGE.defaultBlockState().setValue(EnrichmentCentrifugeBlock.FACING, Direction.NORTH));
        helper.setBlock(generator, ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            if (blockEntity(helper, generator) instanceof BackupGeneratorBlockEntity gen) gen.insertFuel(new ItemStack(Items.COAL, 8), false);
            EnrichmentCentrifugeBlockEntity centrifuge = centrifuge(helper, machine);
            helper.assertTrue(centrifuge.insert(new ItemStack(ModItems.DEPLETED_FUEL_ROD), false) == 0,
                    "Depleted Fuel Rods (spent enriched fuel) must not go in");
            helper.assertTrue(centrifuge.insert(new ItemStack(ModItems.DEPLETED_REDSTONE_FUEL_ROD), false) == 1, "The depleted rod should go in");
            helper.assertTrue(centrifuge.insert(new ItemStack(Items.REDSTONE, config.centrifugeDust), false) == config.centrifugeDust,
                    "The redstone dust should go in");
        });
        helper.runAfterDelay(20, () -> {
            helper.assertTrue(centrifuge(helper, machine).isSpinning(), "The centrifuge should spin on power from its back: "
                    + centrifuge(helper, machine).waitingFor());
        });
        helper.runAfterDelay(150, () -> {
            EnrichmentCentrifugeBlockEntity centrifuge = centrifuge(helper, machine);
            EnrichmentCentrifugeBlockEntity.Kind redstone = EnrichmentCentrifugeBlockEntity.Kind.REDSTONE;
            helper.assertTrue(centrifuge.done(redstone) == 1, "One enriched redstone rod should be done (" + centrifuge.done(redstone) + ")");
            helper.assertTrue(centrifuge.rods(redstone) == 0 && centrifuge.dust(redstone) == 0, "The rod and the dust should be used up");
            helper.assertTrue(centrifuge.takeDone(redstone).is(ModItems.ENRICHED_REDSTONE_FUEL_ROD), "It should give an Enriched Redstone Fuel Rod");
            config.centrifugeTicks = ticks;
            config.centrifugePower = power;
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 300)
    public void withdrawnRodsMakePowerAndLight(GameTestHelper helper) {
        buildReactor(helper);
        helper.runAfterDelay(40, () -> start(helper, 0.0));
        helper.runAfterDelay(200, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            helper.assertTrue(controller.powerLevel() > 0.1, "Power too low with rods out: " + format(controller.powerLevel()));
            BlockState fuel = helper.getBlockState(CENTER_FUEL);
            helper.assertTrue(fuel.getValue(FuelChannelBlock.GLOW) > 0, "The centre fuel channel should glow");
            int light = helper.getLevel().getBrightness(LightLayer.BLOCK, helper.absolutePos(CENTER_FUEL));
            helper.assertTrue(light > 0, "The centre fuel channel should give off light (block light " + light + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 400)
    public void scramStopsFission(GameTestHelper helper) {
        buildReactor(helper);
        helper.runAfterDelay(40, () -> start(helper, 0.0));
        helper.runAfterDelay(160, () -> controller(helper).scram(helper.getLevel(), "game test"));
        helper.runAfterDelay(300, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            helper.assertTrue(controller.isScrammed(), "Reactor should be scrammed");
            helper.assertTrue(controller.effectiveInsertion() == 1.0, "SCRAM should drive the rods fully in");
            helper.assertTrue(controller.powerLevel() < 0.01, "Fission should stop after a SCRAM: " + format(controller.powerLevel()));
            helper.assertTrue(helper.getBlockState(CENTER_FUEL).getValue(FuelChannelBlock.GLOW) == 0, "Fuel should stop glowing after a SCRAM");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 1000)
    public void powerModeHoldsTarget(GameTestHelper helper) {
        buildReactor(helper);
        helper.runAfterDelay(40, () -> {
            start(helper, 100.0);
            ReactorControllerBlockEntity controller = controller(helper);
            controller.setControlMode(ReactorControllerBlockEntity.ControlMode.POWER);
            controller.setTargetPower(15.0);
        });
        helper.runAfterDelay(900, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            double power = controller.powerLevel();
            helper.assertTrue(Math.abs(power - 0.15) < 0.03, "Power should settle near 15%, got " + format(power)
                    + " with rods " + format(controller.insertion()) + "% in");
            helper.assertTrue(controller.insertion() > 1.0 && controller.insertion() < 99.0, "Rods should rest part-way, got "
                    + format(controller.insertion()) + "%");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 400)
    public void temperatureModeWithdrawsRodsWhenCold(GameTestHelper helper) {
        buildReactor(helper);
        helper.runAfterDelay(40, () -> {
            start(helper, 100.0);
            ReactorControllerBlockEntity controller = controller(helper);
            controller.setControlMode(ReactorControllerBlockEntity.ControlMode.TEMPERATURE);
            controller.setTargetTemp(500.0);
        });
        helper.runAfterDelay(340, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            helper.assertTrue(controller.insertion() < 5.0, "A cold core below its target should pull the rods out, got "
                    + format(controller.insertion()) + "% in");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 500)
    public void redstoneModeFollowsSignal(GameTestHelper helper) {
        buildReactor(helper);
        BlockPos signal = CONTROLLER.relative(Direction.SOUTH);
        helper.runAfterDelay(40, () -> {
            start(helper, 100.0);
            controller(helper).setControlMode(ReactorControllerBlockEntity.ControlMode.REDSTONE);
            helper.setBlock(signal, Blocks.REDSTONE_BLOCK);
        });
        helper.runAfterDelay(200, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            helper.assertTrue(!controller.isScrammed(), "In redstone mode a signal must not SCRAM the reactor");
            helper.assertTrue(controller.insertion() < 5.0, "Signal 15 should pull the rods out, got " + format(controller.insertion()) + "% in");
            helper.setBlock(signal, Blocks.AIR);
        });
        helper.runAfterDelay(380, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            helper.assertTrue(controller.insertion() > 95.0, "No signal should drive the rods in, got " + format(controller.insertion()) + "% in");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 100)
    public void stackedControlRodsFillFromTheTop(GameTestHelper helper) {
        buildReactor(helper);
        // Turn the control channel at (3, 3, 2) into a stack three channels tall.
        BlockPos top = new BlockPos(3, 4, 2);
        BlockPos middle = new BlockPos(3, 3, 2);
        BlockPos bottom = new BlockPos(3, 2, 2);
        BlockState rod = ModBlocks.CONTROL_ROD_CHANNEL.defaultBlockState().setValue(ControlRodChannelBlock.HAS_ROD, true);
        helper.setBlock(top, rod);
        helper.setBlock(bottom, rod);
        helper.runAfterDelay(40, () -> start(helper, 50.0));
        helper.runAfterDelay(45, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            double inTop = controller.insertionAt(helper.absolutePos(top));
            double inMiddle = controller.insertionAt(helper.absolutePos(middle));
            double inBottom = controller.insertionAt(helper.absolutePos(bottom));
            String all = format(inTop) + " / " + format(inMiddle) + " / " + format(inBottom);
            helper.assertTrue(Math.abs(inTop - 1.0) < 1.0e-6, "Half inserted, the top rod should be fully in: " + all);
            helper.assertTrue(Math.abs(inMiddle - 0.5) < 1.0e-6, "Half inserted, the middle rod should be half in: " + all);
            helper.assertTrue(inBottom < 1.0e-6, "Half inserted, the bottom rod should still be out: " + all);
            // A lone channel next to the stack follows the insertion directly.
            double lone = controller.insertionAt(helper.absolutePos(new BlockPos(2, 3, 3)));
            helper.assertTrue(Math.abs(lone - 0.5) < 1.0e-6, "A lone channel should be half in: " + format(lone));
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 100)
    public void makeUpWaterNeverOverfillsTheLoop(GameTestHelper helper) {
        buildReactor(helper);
        helper.runAfterDelay(40, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            helper.assertTrue(controller.isFormed(), "Reactor did not form: " + controller.status().getString());
            if (!controller.isPressurized()) {
                String error = controller.togglePressurized();
                helper.assertTrue(error == null, "Could not switch to pressurized mode: " + error);
            }
        });
        helper.runAfterDelay(45, () -> {
            ReactorControllerBlockEntity controller = controller(helper);
            FluidHandler port = controller.portHandler(helper.absolutePos(new BlockPos(1, 3, 3)));
            double vessel = controller.vesselCapacity();
            double makeUp = NuclearConfig.get().makeUpLevel;
            port.insert(Direction.WEST, FluidType.WATER, vessel * 2.0, false);
            helper.assertTrue(Math.abs(controller.coolantLevel() - makeUp) < 0.01,
                    "Make-up water should stop at " + format(makeUp) + " full, the vessel is " + format(controller.coolantLevel()));
            port.insert(Direction.WEST, FluidType.COOLANT, vessel * 2.0, false);
            helper.assertTrue(controller.coolantLevel() > 0.99, "Returning coolant should fill the vessel: " + format(controller.coolantLevel()));
            double extra = port.insert(Direction.WEST, FluidType.WATER, 1000.0, false);
            helper.assertTrue(extra <= 0.0, "A full loop should refuse make-up water, took " + format(extra));
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 20)
    public void xenonPeaksAfterAShutdown(GameTestHelper helper) {
        // The xenon of a core is plain arithmetic, so run it ahead without a reactor: two hours (of game
        // minutes standing for hours) at full power, then a shutdown.
        helper.runAfterDelay(1, () -> {
            NuclearConfig config = NuclearConfig.get();
            if (!config.xenonPoisoning) {
                helper.succeed();
                return;
            }
            int minute = (int) Math.round(1200.0 * config.xenonTimeScale);
            Xenon xenon = new Xenon();
            for (int t = 0; t < 120 * minute; t++) xenon.tick(1.0);
            helper.assertTrue(Math.abs(xenon.level() - 1.0) < 0.01, "Full power should settle at the full-power level (" + format(xenon.level()) + ")");
            double peak = 0.0;
            int peakAt = 0;
            for (int t = 1; t <= 60 * minute; t++) {
                xenon.tick(0.0);
                if (xenon.level() > peak) {
                    peak = xenon.level();
                    peakAt = t;
                }
            }
            helper.assertTrue(peak > 1.2, "After a shutdown the xenon should first rise (peak " + format(peak) + ")");
            helper.assertTrue(peakAt > minute && peakAt < 20 * minute,
                    "The peak should come a few minutes after the shutdown (" + format(peakAt / (double) minute) + " min)");
            helper.assertTrue(xenon.level() < 0.5, "Then it should fade (" + format(xenon.level()) + " after an hour)");
            helper.succeed();
        });
    }

    @GameTest
    public void hazmatSuitProtects(GameTestHelper helper) {
        LivingEntity stand = helper.spawn(EntityTypes.ARMOR_STAND, 3, 1, 3);
        helper.assertTrue(RadiationHandler.protection(stand) == 0.0, "No suit should give no protection");
        stand.setItemSlot(EquipmentSlot.HEAD, RadiationHandler.hazmatPiece(Items.LEATHER_HELMET, "Hazmat Helmet"));
        stand.setItemSlot(EquipmentSlot.CHEST, RadiationHandler.hazmatPiece(Items.LEATHER_CHESTPLATE, "Hazmat Jacket"));
        helper.assertTrue(RadiationHandler.protection(stand) == 0.5, "Two pieces should block 50%");
        stand.setItemSlot(EquipmentSlot.LEGS, RadiationHandler.hazmatPiece(Items.LEATHER_LEGGINGS, "Hazmat Trousers"));
        stand.setItemSlot(EquipmentSlot.FEET, RadiationHandler.hazmatPiece(Items.LEATHER_BOOTS, "Hazmat Boots"));
        helper.assertTrue(RadiationHandler.protection(stand) == 1.0, "A full suit should block everything");
        stand.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
        helper.assertTrue(RadiationHandler.protection(stand) == 0.75, "Plain leather is not part of the suit");
        helper.succeed();
    }

    @GameTest(maxTicks = 40)
    public void pipeWallPortJoinsPipes(GameTestHelper helper) {
        List<BlockPos> line = List.of(new BlockPos(1, 1, 3), new BlockPos(2, 1, 3), new BlockPos(3, 1, 3));
        helper.setBlock(line.get(0), ModBlocks.FLUID_PIPE.defaultBlockState());
        helper.setBlock(line.get(1), ModBlocks.PIPE_WALL_PORT.defaultBlockState());
        helper.setBlock(line.get(2), ModBlocks.FLUID_PIPE.defaultBlockState());
        // Work out every connection once all three are placed.
        for (BlockPos pos : line) {
            BlockPos absolute = helper.absolutePos(pos);
            BlockState state = helper.getLevel().getBlockState(absolute);
            helper.getLevel().setBlock(absolute, FluidPipeBlock.computeState(helper.getLevel(), absolute, state), 3);
        }
        helper.runAfterDelay(2, () -> {
            PipeNetworks networks = PipeNetworks.of(helper.getLevel());
            PipeNetwork first = networks.networkAt(helper.absolutePos(line.get(0)));
            PipeNetwork last = networks.networkAt(helper.absolutePos(line.get(2)));
            helper.assertTrue(first != null && first == last, "Pipes on both sides of a Pipe Wall Port should form one network");
            helper.assertTrue(first.pipes().size() == 3, "The wall port should count as a pipe, network size " + first.pipes().size());
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 40)
    public void cableWallPortJoinsCables(GameTestHelper helper) {
        BlockPos generator = new BlockPos(1, 1, 3);
        BlockPos lamp = new BlockPos(5, 1, 3);
        helper.setBlock(generator, ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        helper.setBlock(new BlockPos(2, 1, 3), ModBlocks.POWER_CABLE.defaultBlockState());
        helper.setBlock(new BlockPos(3, 1, 3), ModBlocks.CABLE_WALL_PORT.defaultBlockState());
        helper.setBlock(new BlockPos(4, 1, 3), ModBlocks.POWER_CABLE.defaultBlockState());
        helper.setBlock(lamp, ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.runAfterDelay(5, () -> {
            PowerGrid grid = PowerGrid.of(helper.getLevel());
            PowerNetwork a = grid.networkAt(helper.absolutePos(generator));
            PowerNetwork b = grid.networkAt(helper.absolutePos(lamp));
            helper.assertTrue(a != null && a == b, "A generator and a lamp on either side of a Cable Wall Port should share one grid");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void checkValveTopsUpForward(GameTestHelper helper) {
        List<BlockPos> supply = List.of(new BlockPos(1, 1, 3), new BlockPos(2, 1, 3), new BlockPos(3, 1, 3));
        List<BlockPos> outlet = List.of(new BlockPos(5, 1, 3), new BlockPos(6, 1, 3));
        buildValveLine(helper, supply, outlet);
        helper.runAfterDelay(2, () -> network(helper, supply.get(0)).insert(Direction.UP, FluidType.WATER, 750.0, false));
        helper.runAfterDelay(40, () -> {
            PipeNetwork out = network(helper, outlet.get(0));
            helper.assertTrue(out.amount() > 0.0, "Water should pass the valve forwards");
            helper.assertTrue(out.fillLevel(Direction.UP) >= 0.75 && out.fillLevel(Direction.UP) <= 1.0,
                    "The valve should top the outlet side up to about 80%, got " + format(out.fillLevel(Direction.UP)));
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void checkValveStopsAtItsOwnLevel(GameTestHelper helper) {
        // The same line, with this valve set to top up to 50% instead of 80%.
        List<BlockPos> supply = List.of(new BlockPos(1, 1, 3), new BlockPos(2, 1, 3), new BlockPos(3, 1, 3));
        List<BlockPos> outlet = List.of(new BlockPos(5, 1, 3), new BlockPos(6, 1, 3));
        buildValveLine(helper, supply, outlet);
        helper.runAfterDelay(2, () -> {
            CheckValveBlockEntity valve = checkValve(helper);
            valve.setSetting(50);
            helper.assertTrue(valve.setting() == 50, "The valve should keep its own level (" + valve.setting() + "%)");
            network(helper, supply.get(0)).insert(Direction.UP, FluidType.WATER, 750.0, false);
        });
        helper.runAfterDelay(40, () -> {
            double fill = network(helper, outlet.get(0)).fillLevel(Direction.UP);
            helper.assertTrue(fill >= 0.45 && fill < 0.75, "The valve should top the outlet side up to about 50%, got " + format(fill));
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void overflowValveSpillsOnlyTheExcess(GameTestHelper helper) {
        // The supply line (750 mB of room) is full; an Overflow valve at 60% lets out only what is over 60%.
        List<BlockPos> supply = List.of(new BlockPos(1, 1, 3), new BlockPos(2, 1, 3), new BlockPos(3, 1, 3));
        List<BlockPos> outlet = List.of(new BlockPos(5, 1, 3), new BlockPos(6, 1, 3));
        buildValveLine(helper, supply, outlet);
        helper.runAfterDelay(2, () -> {
            CheckValveBlockEntity valve = checkValve(helper);
            valve.setMode(CheckValveBlockEntity.Mode.OVERFLOW);
            valve.setSetting(60);
            network(helper, supply.get(0)).insert(Direction.UP, FluidType.WATER, 750.0, false);
        });
        helper.runAfterDelay(40, () -> {
            double fill = network(helper, supply.get(0)).fillLevel(Direction.UP);
            double out = network(helper, outlet.get(0)).amount();
            helper.assertTrue(Math.abs(fill - 0.6) < 0.01, "The supply side should be let down to 60%, got " + format(fill));
            helper.assertTrue(Math.abs(out - 300.0) < 1.0, "Only the 300 mB over 60% should pass (" + format(out) + " mB)");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 40)
    public void expansionTanksShareTheirWater(GameTestHelper helper) {
        // Two tanks side by side, both facing north (front north, back south).
        BlockPos first = new BlockPos(2, 1, 2);
        BlockPos second = first.east();
        helper.setBlock(first, ModBlocks.EXPANSION_TANK.defaultBlockState());
        helper.setBlock(second, ModBlocks.EXPANSION_TANK.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            ExpansionTankBlockEntity a = tank(helper, first);
            ExpansionTankBlockEntity b = tank(helper, second);
            double perTank = NuclearConfig.get().expansionTankCapacity;
            helper.assertTrue(a.insert(Direction.SOUTH, FluidType.WATER, 100.0, true) == 0.0, "Water only goes in at the front");
            helper.assertTrue(a.insert(Direction.NORTH, FluidType.COOLANT, 100.0, true) == 0.0, "Only water goes in");
            helper.assertTrue(a.insert(Direction.NORTH, FluidType.WATER, 3.0 * perTank, false) == 2.0 * perTank,
                    "Two joined tanks should hold twice one tank's water");
            helper.assertTrue(b.extract(Direction.NORTH, FluidType.WATER, 100.0, false, true) == 0.0, "Water only comes out at the back");
            double out = b.extract(Direction.SOUTH, FluidType.WATER, 1000.0, false, false);
            helper.assertTrue(out == 1000.0, "Water put in one tank should come out of the other (" + format(out) + " mB)");
            double fill = b.fillLevel(Direction.SOUTH);
            helper.assertTrue(Math.abs(fill - (2.0 * perTank - 1000.0) / (2.0 * perTank)) < 1.0e-6, "Both should see the group's fill (" + format(fill) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 40)
    public void tankDrawsFromItsFrontPipeAndFillsItsBackPipe(GameTestHelper helper) {
        // A tank facing north between two pipes: water put in the front pipe ends up in the back pipe.
        BlockPos tankPos = new BlockPos(2, 1, 2);
        BlockPos frontPipe = tankPos.north();
        BlockPos backPipe = tankPos.south();
        helper.setBlock(tankPos, ModBlocks.EXPANSION_TANK.defaultBlockState());
        helper.setBlock(frontPipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        helper.setBlock(backPipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        recompute(helper, frontPipe);
        recompute(helper, backPipe);
        helper.runAfterDelay(2, () -> network(helper, frontPipe).insert(Direction.UP, FluidType.WATER, 250.0, false));
        helper.runAfterDelay(30, () -> {
            double front = network(helper, frontPipe).amount();
            double back = network(helper, backPipe).amount();
            helper.assertTrue(front < 1.0, "The tank should draw the water from the pipe at its front (" + format(front) + " mB left)");
            helper.assertTrue(back > 249.0, "The tank should push the water into the pipe at its back (" + format(back) + " mB)");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 40)
    public void brokenTankTakesItsShare(GameTestHelper helper) {
        BlockPos first = new BlockPos(2, 1, 2);
        BlockPos second = first.above();
        helper.setBlock(first, ModBlocks.EXPANSION_TANK.defaultBlockState());
        helper.setBlock(second, ModBlocks.EXPANSION_TANK.defaultBlockState());
        double perTank = NuclearConfig.get().expansionTankCapacity;
        helper.runAfterDelay(2, () -> tank(helper, first).insert(Direction.NORTH, FluidType.WATER, 2.0 * perTank, false));
        helper.runAfterDelay(4, () -> helper.setBlock(second, Blocks.AIR.defaultBlockState()));
        helper.runAfterDelay(8, () -> {
            double left = tank(helper, first).extract(Direction.SOUTH, FluidType.WATER, 3.0 * perTank, false, true);
            helper.assertTrue(Math.abs(left - perTank) < 1.0e-6, "The tank left should keep its own share (" + format(left) + " mB)");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void checkValveBlocksBackflow(GameTestHelper helper) {
        List<BlockPos> supply = List.of(new BlockPos(1, 1, 3), new BlockPos(2, 1, 3), new BlockPos(3, 1, 3));
        List<BlockPos> outlet = List.of(new BlockPos(5, 1, 3), new BlockPos(6, 1, 3));
        buildValveLine(helper, supply, outlet);
        helper.runAfterDelay(2, () -> network(helper, outlet.get(0)).insert(Direction.UP, FluidType.WATER, 500.0, false));
        helper.runAfterDelay(40, () -> {
            helper.assertTrue(network(helper, supply.get(0)).amount() == 0.0, "No water may flow back through the valve");
            helper.assertTrue(network(helper, outlet.get(0)).amount() > 499.0, "The outlet side should keep its water");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void heatExchangerFacesHaveOneJob(GameTestHelper helper) {
        BlockPos exchanger = new BlockPos(3, 2, 3);
        BlockPos steamPipe = exchanger.south();
        BlockPos coldPipe = exchanger.west();
        helper.setBlock(exchanger, ModBlocks.HEAT_EXCHANGER.defaultBlockState().setValue(HeatExchangerBlock.FACING, Direction.SOUTH));
        helper.setBlock(steamPipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        helper.setBlock(coldPipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        for (BlockPos pos : List.of(steamPipe, coldPipe)) {
            BlockPos absolute = helper.absolutePos(pos);
            helper.getLevel().setBlock(absolute, FluidPipeBlock.computeState(helper.getLevel(), absolute, helper.getLevel().getBlockState(absolute)), 3);
        }
        helper.runAfterDelay(2, () -> {
            if (!(blockEntity(helper, exchanger) instanceof HeatExchangerBlockEntity hx)) {
                throw helper.assertionException("No heat exchanger block entity");
            }
            helper.assertTrue(hx.insert(Direction.UP, FluidType.WATER, 100.0, true) == 0.0, "The top must only take coolant");
            helper.assertTrue(hx.insert(Direction.DOWN, FluidType.COOLANT, 100.0, true) == 0.0, "The bottom must only take water");
            helper.assertTrue(hx.insert(Direction.WEST, FluidType.WATER, 100.0, true) == 0.0, "The sides must not take anything in");
            helper.assertTrue(hx.insert(Direction.UP, FluidType.COOLANT, 500.0, 300.0, false) == 500.0, "The top should take coolant");
            helper.assertTrue(hx.insert(Direction.DOWN, FluidType.WATER, 1000.0, false) == 1000.0, "The bottom should take water");
        });
        helper.runAfterDelay(40, () -> {
            PipeNetwork cold = network(helper, coldPipe);
            PipeNetwork steam = network(helper, steamPipe);
            helper.assertTrue(steam.type() == FluidType.STEAM && steam.amount() > 0.0, "Steam should come out of the front");
            helper.assertTrue(cold.amount() == 0.0, "Coolant must not leave on its own (a circulation pump draws it)");
            if (!(blockEntity(helper, exchanger) instanceof HeatExchangerBlockEntity hx)) {
                throw helper.assertionException("No heat exchanger block entity");
            }
            helper.assertTrue(hx.extract(Direction.WEST, FluidType.COOLANT, 100.0, false, true) == 0.0,
                    "Only a pump may draw the coolant");
            helper.assertTrue(hx.extract(Direction.WEST, FluidType.COOLANT, 100.0, true, true) > 0.0,
                    "A pump should be able to draw the coolant from a side");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void coolCoolantMakesNoSteam(GameTestHelper helper) {
        // Coolant at 55 °C (a reactor that has been shut down) passes through, but makes no steam.
        BlockPos exchanger = new BlockPos(2, 2, 2);
        helper.setBlock(exchanger, ModBlocks.HEAT_EXCHANGER.defaultBlockState().setValue(HeatExchangerBlock.FACING, Direction.SOUTH));
        helper.runAfterDelay(2, () -> {
            HeatExchangerBlockEntity hx = exchanger(helper, exchanger);
            hx.insert(Direction.UP, FluidType.COOLANT, 500.0, 55.0, false);
            hx.insert(Direction.DOWN, FluidType.WATER, 1000.0, false);
        });
        helper.runAfterDelay(30, () -> {
            HeatExchangerBlockEntity hx = exchanger(helper, exchanger);
            double steam = hx.extract(Direction.SOUTH, FluidType.STEAM, 5000.0, false, true);
            double through = hx.extract(Direction.WEST, FluidType.COOLANT, 5000.0, true, true);
            double outTemp = hx.temperature(Direction.WEST, FluidType.COOLANT);
            helper.assertTrue(steam == 0.0, "Coolant below the minimum temperature must not make steam (" + format(steam) + " mB made)");
            helper.assertTrue(through > 0.0, "The coolant should still flow through (" + format(through) + ")");
            helper.assertTrue(Math.abs(outTemp - 55.0) < 0.01, "The coolant should leave as warm as it came (" + format(outTemp) + " °C)");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void hotCoolantCoolsDownMakingSteam(GameTestHelper helper) {
        // Coolant at 300 °C makes steam and leaves at the minimum temperature (150 °C by default).
        BlockPos exchanger = new BlockPos(2, 2, 2);
        helper.setBlock(exchanger, ModBlocks.HEAT_EXCHANGER.defaultBlockState().setValue(HeatExchangerBlock.FACING, Direction.SOUTH));
        helper.runAfterDelay(2, () -> {
            HeatExchangerBlockEntity hx = exchanger(helper, exchanger);
            hx.insert(Direction.UP, FluidType.COOLANT, 500.0, 300.0, false);
            hx.insert(Direction.DOWN, FluidType.WATER, 2000.0, false);
        });
        helper.runAfterDelay(30, () -> {
            HeatExchangerBlockEntity hx = exchanger(helper, exchanger);
            double steam = hx.extract(Direction.SOUTH, FluidType.STEAM, 5000.0, false, true);
            double outTemp = hx.temperature(Direction.WEST, FluidType.COOLANT);
            double minimum = NuclearConfig.get().heatExchangerMinTemp;
            double steamTemp = hx.temperature(Direction.SOUTH, FluidType.STEAM);
            double expected = 300.0 - NuclearConfig.get().steamApproachTemp;
            helper.assertTrue(steam > 0.0, "Hot coolant should make steam");
            helper.assertTrue(Math.abs(steamTemp - expected) < 0.5, "The steam should come out at " + format(expected) + " °C (" + format(steamTemp) + ")");
            helper.assertTrue(Math.abs(outTemp - minimum) < 0.5, "The coolant should leave at " + format(minimum) + " °C (" + format(outTemp) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void exchangerLeaksALittleCoolant(GameTestHelper helper) {
        // 500 mB of coolant goes through an exchanger with nothing drawing it out: all of it but the leak is waiting
        // at the outlets.
        BlockPos exchanger = new BlockPos(2, 2, 2);
        helper.setBlock(exchanger, ModBlocks.HEAT_EXCHANGER.defaultBlockState().setValue(HeatExchangerBlock.FACING, Direction.SOUTH));
        helper.runAfterDelay(2, () -> exchanger(helper, exchanger).insert(Direction.UP, FluidType.COOLANT, 500.0, 55.0, false));
        helper.runAfterDelay(40, () -> {
            double through = exchanger(helper, exchanger).extract(Direction.WEST, FluidType.COOLANT, 5000.0, true, true);
            double expected = 500.0 * (1.0 - NuclearConfig.get().heatExchangerCoolantLoss);
            helper.assertTrue(Math.abs(through - expected) < 0.01,
                    "All but the leak should come through: " + format(expected) + " mB (got " + format(through) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 40)
    public void pumpsIntoOnePipeShareIt(GameTestHelper helper) {
        BlockPos pipe = new BlockPos(3, 1, 2);
        BlockPos first = pipe.west();
        BlockPos second = pipe.north();
        helper.setBlock(first, ModBlocks.CIRCULATION_PUMP.defaultBlockState().setValue(CirculationPumpBlock.FACING, Direction.EAST));
        helper.setBlock(second, ModBlocks.CIRCULATION_PUMP.defaultBlockState().setValue(CirculationPumpBlock.FACING, Direction.SOUTH));
        helper.setBlock(pipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        BlockPos absolutePipe = helper.absolutePos(pipe);
        helper.getLevel().setBlock(absolutePipe, FluidPipeBlock.computeState(helper.getLevel(), absolutePipe, helper.getLevel().getBlockState(absolutePipe)), 3);
        helper.runAfterDelay(2, () -> {
            // Fill both pumps from their backs; the single pipe (250 mB) cannot take both loads.
            pump(helper, first).insert(Direction.WEST, FluidType.COOLANT, 200.0, false);
            pump(helper, second).insert(Direction.NORTH, FluidType.COOLANT, 200.0, false);
        });
        helper.runAfterDelay(10, () -> {
            double a = pump(helper, first).extract(Direction.EAST, FluidType.COOLANT, 1000.0, false, true);
            double b = pump(helper, second).extract(Direction.SOUTH, FluidType.COOLANT, 1000.0, false, true);
            helper.assertTrue(a < 200.0 && b < 200.0, "Both pumps should push (left in pumps: " + format(a) + " and " + format(b) + ")");
            helper.assertTrue(Math.abs(a - b) < 1.0, "The pumps should share the pipe evenly (left: " + format(a) + " and " + format(b) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void exchangersShareOneSteamPipe(GameTestHelper helper) {
        BlockPos pipe = new BlockPos(3, 2, 2);
        BlockPos first = pipe.west();
        BlockPos second = pipe.east();
        helper.setBlock(first, ModBlocks.HEAT_EXCHANGER.defaultBlockState().setValue(HeatExchangerBlock.FACING, Direction.EAST));
        helper.setBlock(second, ModBlocks.HEAT_EXCHANGER.defaultBlockState().setValue(HeatExchangerBlock.FACING, Direction.WEST));
        helper.setBlock(pipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        recompute(helper, pipe);
        helper.runAfterDelay(2, () -> {
            for (BlockPos pos : List.of(first, second)) {
                HeatExchangerBlockEntity hx = exchanger(helper, pos);
                hx.insert(Direction.UP, FluidType.COOLANT, 500.0, 300.0, false);
                hx.insert(Direction.DOWN, FluidType.WATER, 1000.0, false);
            }
        });
        helper.runAfterDelay(30, () -> {
            // Both fronts push into one pipe (250 mB) with nothing taking the steam: each should get half.
            double a = exchanger(helper, first).extract(Direction.EAST, FluidType.STEAM, 5000.0, false, true);
            double b = exchanger(helper, second).extract(Direction.WEST, FluidType.STEAM, 5000.0, false, true);
            helper.assertTrue(Math.abs(a - b) < 1.0, "Both exchangers should share the steam pipe (steam left: " + format(a) + " and " + format(b) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 100)
    public void pumpDrawsEvenlyFromSeveralExchangers(GameTestHelper helper) {
        BlockPos pipe = new BlockPos(3, 2, 2);
        BlockPos first = pipe.west();
        BlockPos second = pipe.east();
        BlockPos pumpPos = pipe.south();
        BlockPos generator = pumpPos.above();
        // Fronts face north, so the pipe touches a coolant outlet on each exchanger.
        helper.setBlock(first, ModBlocks.HEAT_EXCHANGER.defaultBlockState().setValue(HeatExchangerBlock.FACING, Direction.NORTH));
        helper.setBlock(second, ModBlocks.HEAT_EXCHANGER.defaultBlockState().setValue(HeatExchangerBlock.FACING, Direction.NORTH));
        helper.setBlock(pumpPos, ModBlocks.CIRCULATION_PUMP.defaultBlockState().setValue(CirculationPumpBlock.FACING, Direction.SOUTH));
        helper.setBlock(generator, ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        helper.setBlock(pipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        recompute(helper, pipe);
        helper.runAfterDelay(2, () -> {
            if (blockEntity(helper, generator) instanceof BackupGeneratorBlockEntity gen) {
                gen.insertFuel(new ItemStack(Items.COAL, 8), false);
            }
            for (BlockPos pos : List.of(first, second)) {
                HeatExchangerBlockEntity hx = exchanger(helper, pos);
                hx.insert(Direction.UP, FluidType.COOLANT, 600.0, 300.0, false);
                hx.insert(Direction.DOWN, FluidType.WATER, 1000.0, false);
            }
        });
        helper.runAfterDelay(40, () -> {
            double a = exchanger(helper, first).extract(Direction.EAST, FluidType.COOLANT, 5000.0, true, true);
            double b = exchanger(helper, second).extract(Direction.WEST, FluidType.COOLANT, 5000.0, true, true);
            helper.assertTrue(a < 600.0 && b < 600.0, "The pump should draw from both exchangers (left: " + format(a) + " and " + format(b) + ")");
            helper.assertTrue(Math.abs(a - b) < 1.0, "The pump should draw evenly (left: " + format(a) + " and " + format(b) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void pipeKnowsWhatPassesThrough(GameTestHelper helper) {
        // A pump draws coolant from an exchanger outlet through a pipe: nothing waits in that pipe, but the
        // coolant goes through it, and the pipe knows what and how much.
        BlockPos pipe = new BlockPos(3, 2, 2);
        BlockPos exchangerPos = pipe.west();
        BlockPos pumpPos = pipe.south();
        BlockPos generator = pumpPos.above();
        List<BlockPos> outlet = List.of(pumpPos.south(), pumpPos.south(2), pumpPos.south(3));
        helper.setBlock(exchangerPos, ModBlocks.HEAT_EXCHANGER.defaultBlockState().setValue(HeatExchangerBlock.FACING, Direction.NORTH));
        helper.setBlock(pumpPos, ModBlocks.CIRCULATION_PUMP.defaultBlockState().setValue(CirculationPumpBlock.FACING, Direction.SOUTH));
        helper.setBlock(generator, ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        helper.setBlock(pipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        for (BlockPos pos : outlet) helper.setBlock(pos, ModBlocks.FLUID_PIPE.defaultBlockState());
        recompute(helper, pipe);
        for (BlockPos pos : outlet) recompute(helper, pos);
        helper.runAfterDelay(2, () -> {
            if (blockEntity(helper, generator) instanceof BackupGeneratorBlockEntity gen) {
                gen.insertFuel(new ItemStack(Items.COAL, 8), false);
            }
            // No feedwater, so the coolant passes through the exchanger at the temperature it came in with.
            exchanger(helper, exchangerPos).insert(Direction.UP, FluidType.COOLANT, 1000.0, 300.0, false);
        });
        helper.runAfterDelay(14, () -> {
            PipeNetwork network = network(helper, pipe);
            helper.assertTrue(network.amount() < 1.0, "Nothing should wait in the pipe (holds " + format(network.amount()) + ")");
            helper.assertTrue(network.flowingType() == FluidType.COOLANT, "The pipe should know coolant flows through it");
            helper.assertTrue(network.flowOut() > 1.0, "The pipe should measure the flow (got " + format(network.flowOut()) + " mB/t)");
            helper.assertTrue(Math.abs(network.flowTemperature() - 300.0) < 1.0,
                    "The flow should be at 300 °C (got " + format(network.flowTemperature()) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void pumpsShareOneExchanger(GameTestHelper helper) {
        // One exchanger (front north) with a circulation pump drawing on each of its three coolant outlets.
        BlockPos exchanger = new BlockPos(3, 2, 3);
        List<BlockPos> pumps = List.of(exchanger.west(), exchanger.east(), exchanger.south());
        List<Direction> outlets = List.of(Direction.WEST, Direction.EAST, Direction.SOUTH);
        helper.setBlock(exchanger, ModBlocks.HEAT_EXCHANGER.defaultBlockState().setValue(HeatExchangerBlock.FACING, Direction.NORTH));
        for (int i = 0; i < pumps.size(); i++) {
            helper.setBlock(pumps.get(i), ModBlocks.CIRCULATION_PUMP.defaultBlockState().setValue(CirculationPumpBlock.FACING, outlets.get(i)));
            helper.setBlock(pumps.get(i).above(), ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        }
        helper.runAfterDelay(2, () -> {
            for (BlockPos pos : pumps) {
                if (blockEntity(helper, pos.above()) instanceof BackupGeneratorBlockEntity gen) gen.insertFuel(new ItemStack(Items.COAL, 8), false);
            }
            HeatExchangerBlockEntity hx = exchanger(helper, exchanger);
            hx.insert(Direction.UP, FluidType.COOLANT, 600.0, 300.0, false);
            hx.insert(Direction.DOWN, FluidType.WATER, 1000.0, false);
        });
        helper.runAfterDelay(12, () -> {
            // The pumps push into thin air, so what each drew is still in it.
            double[] drawn = new double[pumps.size()];
            for (int i = 0; i < pumps.size(); i++) {
                drawn[i] = pump(helper, pumps.get(i)).extract(outlets.get(i), FluidType.COOLANT, 1000.0, false, true);
            }
            String all = format(drawn[0]) + " / " + format(drawn[1]) + " / " + format(drawn[2]);
            helper.assertTrue(drawn[0] > 0.0, "The pumps should draw the coolant: " + all);
            helper.assertTrue(Math.abs(drawn[0] - drawn[1]) < 1.0 && Math.abs(drawn[0] - drawn[2]) < 1.0,
                    "Three pumps on one exchanger should draw evenly: " + all);
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void turbinesShareTheSteam(GameTestHelper helper) {
        // Two turbines with a gap between them, and one steam pipe running over both tops.
        BlockPos first = new BlockPos(1, 1, 2);
        BlockPos second = new BlockPos(3, 1, 2);
        BlockPos pipe = first.above();
        List<BlockPos> pipes = List.of(pipe, pipe.east(), second.above());
        helper.setBlock(first, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(second, ModBlocks.STEAM_TURBINE.defaultBlockState());
        for (BlockPos pos : pipes) helper.setBlock(pos, ModBlocks.FLUID_PIPE.defaultBlockState());
        for (BlockPos pos : pipes) recompute(helper, pos);
        // Less steam than one turbine would draw in a tick: it must still be split between both.
        helper.runAfterDelay(2, () -> network(helper, pipe).insert(Direction.UP, FluidType.STEAM, 100.0, false));
        helper.runAfterDelay(30, () -> {
            double a = turbine(helper, first).steamBuffer();
            double b = turbine(helper, second).steamBuffer();
            helper.assertTrue(a > 0.0, "The turbines should draw the steam (" + format(a) + " / " + format(b) + ")");
            helper.assertTrue(Math.abs(a - b) < 0.01, "Both turbines should draw the same steam (" + format(a) + " / " + format(b) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void turbineFacesHaveOneJob(GameTestHelper helper) {
        // A turbine facing north with steam, a lamp at its front and a lamp at its back.
        BlockPos turbinePos = new BlockPos(2, 1, 2);
        BlockPos frontLamp = turbinePos.north();
        BlockPos backLamp = turbinePos.south();
        helper.setBlock(turbinePos, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(frontLamp, ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.setBlock(backLamp, ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            SteamTurbineBlockEntity turbine = turbine(helper, turbinePos);
            for (Direction side : List.of(Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.DOWN)) {
                helper.assertTrue(turbine.insert(side, FluidType.STEAM, 100.0, true) == 0.0, "Steam must only go in at the top, not " + side.getName());
            }
            helper.assertTrue(turbine.insert(Direction.UP, FluidType.STEAM, 1000.0, false) > 0.0, "Steam should go in at the top");
            for (Direction side : List.of(Direction.NORTH, Direction.UP, Direction.DOWN)) {
                helper.assertTrue(turbine.terminalAt(side) < 0, "No power on the " + side.getName() + " face");
            }
            for (Direction side : List.of(Direction.EAST, Direction.WEST, Direction.SOUTH)) {
                helper.assertTrue(turbine.terminalAt(side) == 0, "Power should come out of the " + side.getName() + " face");
            }
        });
        helper.runAfterDelay(40, () -> {
            double back = lamp(helper, backLamp).powerFraction();
            double front = lamp(helper, frontLamp).powerFraction();
            helper.assertTrue(back >= 0.999, "The lamp at the back should be powered (" + format(back) + ")");
            helper.assertTrue(front < 0.5, "The lamp at the front (the rotor) should get no power (" + format(front) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 80)
    public void turbineFollowsTheLoad(GameTestHelper helper) {
        // One turbine powering a lamp, one turbine with nothing to power; both have plenty of steam.
        BlockPos loaded = new BlockPos(1, 1, 1);
        BlockPos idle = new BlockPos(4, 1, 1);
        BlockPos lamp = loaded.east();
        helper.setBlock(loaded, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(idle, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(lamp, ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        double[] idleSteam = new double[1];
        helper.runAfterDelay(2, () -> {
            turbine(helper, loaded).insert(Direction.UP, FluidType.STEAM, 1000.0, false);
            idleSteam[0] = turbine(helper, idle).insert(Direction.UP, FluidType.STEAM, 1000.0, false);
        });
        helper.runAfterDelay(50, () -> {
            SteamTurbineBlockEntity busy = turbine(helper, loaded);
            double power = lamp(helper, lamp).powerFraction();
            helper.assertTrue(power >= 0.999, "The turbine should power the lamp (" + format(power) + ")");
            helper.assertTrue(busy.lastSteamUse() > 0.0 && busy.lastSteamUse() < 1.0,
                    "A turbine should only take the steam the lamp needs, not its full rate (" + format(busy.lastSteamUse()) + ")");
            helper.assertTrue(idleSteam[0] > 0.0 && turbine(helper, idle).steamBuffer() >= idleSteam[0] - 1.0e-6,
                    "A turbine with nothing to power should not use steam (" + format(turbine(helper, idle).steamBuffer()) + " left)");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 80)
    public void turbinesSplitTheLoad(GameTestHelper helper) {
        // Two turbines side by side, both with steam, powering one lamp: each makes half.
        BlockPos first = new BlockPos(1, 1, 1);
        BlockPos second = first.east();
        BlockPos lamp = second.east();
        helper.setBlock(first, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(second, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(lamp, ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            turbine(helper, first).insert(Direction.UP, FluidType.STEAM, 1000.0, false);
            turbine(helper, second).insert(Direction.UP, FluidType.STEAM, 1000.0, false);
        });
        helper.runAfterDelay(50, () -> {
            double a = turbine(helper, first).lastOutput();
            double b = turbine(helper, second).lastOutput();
            helper.assertTrue(a > 0.0 && b > 0.0, "Both turbines should run (" + format(a) + " / " + format(b) + ")");
            helper.assertTrue(Math.abs(a - b) < 0.01, "The turbines should split the load evenly (" + format(a) + " / " + format(b) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void batteriesShareTheCharge(GameTestHelper helper) {
        // A generator between two batteries, touching both of their backs.
        BlockPos generator = new BlockPos(2, 1, 1);
        BlockPos first = generator.west();
        BlockPos second = generator.east();
        helper.setBlock(generator, ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        helper.setBlock(first, batteryFacing(Direction.WEST));
        helper.setBlock(second, batteryFacing(Direction.EAST));
        helper.runAfterDelay(2, () -> {
            if (blockEntity(helper, generator) instanceof BackupGeneratorBlockEntity gen) gen.insertFuel(new ItemStack(Items.COAL, 8), false);
        });
        helper.runAfterDelay(30, () -> {
            double a = battery(helper, first).stored();
            double b = battery(helper, second).stored();
            helper.assertTrue(a > 0.0, "The batteries should charge (" + format(a) + " / " + format(b) + ")");
            helper.assertTrue(Math.abs(a - b) < 1.0e-3, "Batteries on one supply should charge evenly (" + format(a) + " / " + format(b) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void batteriesShareTheLoad(GameTestHelper helper) {
        // A lamp between two batteries (both facing north), touching a power-out side of each.
        BlockPos lamp = new BlockPos(2, 1, 1);
        BlockPos first = lamp.west();
        BlockPos second = lamp.east();
        helper.setBlock(lamp, ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.setBlock(first, batteryFacing(Direction.NORTH));
        helper.setBlock(second, batteryFacing(Direction.NORTH));
        helper.runAfterDelay(2, () -> {
            battery(helper, first).charge(1000.0);
            battery(helper, second).charge(1000.0);
        });
        helper.runAfterDelay(30, () -> {
            double a = battery(helper, first).stored();
            double b = battery(helper, second).stored();
            helper.assertTrue(a < 1000.0, "The lamp should draw on the batteries (" + format(a) + " / " + format(b) + ")");
            helper.assertTrue(Math.abs(a - b) < 1.0e-3, "Batteries should share the load evenly (" + format(a) + " / " + format(b) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void batteryChargesOnlyThroughItsBack(GameTestHelper helper) {
        // The generator touches the back of the first battery, the front of the second and a power-out side of
        // the third.
        BlockPos generator = new BlockPos(2, 1, 2);
        BlockPos back = generator.west();
        BlockPos front = generator.east();
        BlockPos side = generator.north();
        helper.setBlock(generator, ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        helper.setBlock(back, batteryFacing(Direction.WEST));
        helper.setBlock(front, batteryFacing(Direction.WEST));
        helper.setBlock(side, batteryFacing(Direction.WEST));
        helper.runAfterDelay(2, () -> {
            if (blockEntity(helper, generator) instanceof BackupGeneratorBlockEntity gen) gen.insertFuel(new ItemStack(Items.COAL, 8), false);
            BatteryBankBlockEntity battery = battery(helper, back);
            helper.assertTrue(battery.terminalAt(Direction.WEST) < 0, "The front (charge gauge) must connect nothing");
            helper.assertTrue(battery.terminalAt(Direction.EAST) == BatteryBankBlockEntity.INPUT, "The back should be the power-in port");
            for (Direction out : List.of(Direction.NORTH, Direction.SOUTH, Direction.UP, Direction.DOWN)) {
                helper.assertTrue(battery.terminalAt(out) == BatteryBankBlockEntity.OUTPUT, "The " + out.getName() + " face should be a power-out port");
            }
        });
        helper.runAfterDelay(30, () -> {
            double a = battery(helper, back).stored();
            double b = battery(helper, front).stored();
            double c = battery(helper, side).stored();
            helper.assertTrue(a > 0.0, "A battery should charge through its back (" + format(a) + ")");
            helper.assertTrue(b == 0.0, "A battery must not charge through its front (" + format(b) + ")");
            helper.assertTrue(c == 0.0, "A battery must not charge through a power-out port (" + format(c) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void stackedBatteriesShareTheirCharge(GameTestHelper helper) {
        // Two batteries stacked (both facing north); only the bottom one has a generator at its back.
        BlockPos bottom = new BlockPos(2, 1, 2);
        BlockPos top = bottom.above();
        BlockPos generator = bottom.south();
        helper.setBlock(bottom, batteryFacing(Direction.NORTH));
        helper.setBlock(top, batteryFacing(Direction.NORTH));
        helper.setBlock(generator, ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            if (blockEntity(helper, generator) instanceof BackupGeneratorBlockEntity gen) gen.insertFuel(new ItemStack(Items.COAL, 8), false);
        });
        helper.runAfterDelay(40, () -> {
            double a = battery(helper, bottom).stored();
            double b = battery(helper, top).stored();
            helper.assertTrue(a > 0.0, "The bottom battery should charge (" + format(a) + ")");
            helper.assertTrue(b > 0.4 * a, "The top battery should get its share through the red ports (" + format(a) + " / " + format(b) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void batteryChargesTheNextOne(GameTestHelper helper) {
        // generator -> back of the first battery (facing north); its east power-out side -> back of the second.
        BlockPos first = new BlockPos(2, 1, 2);
        BlockPos generator = first.south();
        BlockPos second = first.east();
        helper.setBlock(generator, ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        helper.setBlock(first, batteryFacing(Direction.NORTH));
        helper.setBlock(second, batteryFacing(Direction.EAST));
        helper.runAfterDelay(2, () -> {
            if (blockEntity(helper, generator) instanceof BackupGeneratorBlockEntity gen) gen.insertFuel(new ItemStack(Items.COAL, 8), false);
        });
        helper.runAfterDelay(30, () -> {
            double b = battery(helper, second).stored();
            helper.assertTrue(b > 0.0, "A battery should charge the next one through a power-out port (" + format(b) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void pumpTakesPowerThroughItsSides(GameTestHelper helper) {
        // Pump A (facing east) with generators beside it and on top; pump C touching A's other side passes nothing
        // but A; pump B has its generator at its back (a pipe face), which must not power it.
        BlockPos a = new BlockPos(2, 1, 2);
        BlockPos c = a.north();
        BlockPos b = new BlockPos(5, 1, 2);
        BlockState east = ModBlocks.CIRCULATION_PUMP.defaultBlockState().setValue(CirculationPumpBlock.FACING, Direction.EAST);
        helper.setBlock(a, east);
        helper.setBlock(c, east);
        helper.setBlock(b, east);
        List<BlockPos> generators = List.of(a.south(), a.above(), b.west());
        for (BlockPos generator : generators) helper.setBlock(generator, ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            for (BlockPos generator : generators) {
                if (blockEntity(helper, generator) instanceof BackupGeneratorBlockEntity gen) gen.insertFuel(new ItemStack(Items.COAL, 8), false);
            }
            // Something to pump (it has nowhere to go), so the pumps ask for power.
            for (BlockPos pos : List.of(a, b, c)) pump(helper, pos).insert(Direction.WEST, FluidType.COOLANT, 100.0, false);
        });
        helper.runAfterDelay(30, () -> {
            double side = pump(helper, a).powerFraction();
            double neighbour = pump(helper, c).powerFraction();
            double back = pump(helper, b).powerFraction();
            helper.assertTrue(side >= 0.999, "A pump should take power through its sides (" + format(side) + ")");
            helper.assertTrue(neighbour >= 0.999, "A pump should take power from the pump next to it (" + format(neighbour) + ")");
            helper.assertTrue(back <= 0.0, "A pump must not take power through its pipe faces (" + format(back) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void uprightWaterPumpTakesPowerOnItsPortSide(GameTestHelper helper) {
        // Two water pumps pointing up, both with the port on the east side and water to the west; one generator
        // east (on the port), one generator north.
        BlockPos onPort = new BlockPos(1, 1, 2);
        BlockPos offPort = new BlockPos(5, 1, 2);
        BlockState upright = ModBlocks.WATER_PUMP.defaultBlockState()
                .setValue(WaterPumpBlock.FACING, Direction.UP)
                .setValue(ElectricConnectable.POWER_PORT, Direction.EAST);
        helper.setBlock(onPort, upright);
        helper.setBlock(offPort, upright);
        helper.setBlock(onPort.west(), Blocks.WATER.defaultBlockState());
        helper.setBlock(offPort.west(), Blocks.WATER.defaultBlockState());
        List<BlockPos> generators = List.of(onPort.east(), offPort.north());
        for (BlockPos generator : generators) helper.setBlock(generator, ModBlocks.BACKUP_GENERATOR.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            for (BlockPos generator : generators) {
                if (blockEntity(helper, generator) instanceof BackupGeneratorBlockEntity gen) gen.insertFuel(new ItemStack(Items.COAL, 8), false);
            }
        });
        helper.runAfterDelay(30, () -> {
            double on = waterPump(helper, onPort).powerFraction();
            double off = waterPump(helper, offPort).powerFraction();
            helper.assertTrue(on >= 0.999, "An upright water pump should take power through its port side (" + format(on) + ")");
            helper.assertTrue(off <= 0.0, "An upright water pump must not take power through another side (" + format(off) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void batteryPowersItsBackWhenTheGridIsDown(GameTestHelper helper) {
        // A charged battery with a lamp on its back and no generator: the battery keeps the lamp lit.
        BlockPos battery = new BlockPos(2, 1, 1);
        BlockPos lamp = battery.west();
        helper.setBlock(battery, batteryFacing(Direction.EAST));
        helper.setBlock(lamp, ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.runAfterDelay(2, () -> battery(helper, battery).charge(1000.0));
        helper.runAfterDelay(30, () -> {
            double power = lamp(helper, lamp).powerFraction();
            double stored = battery(helper, battery).stored();
            helper.assertTrue(power >= 0.999, "The battery should power the grid at its back when it has no supply (" + format(power) + ")");
            helper.assertTrue(stored < 1000.0, "The battery should be discharging (" + format(stored) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void turbinesShareOneConnection(GameTestHelper helper) {
        // Two turbines side by side; only the first gets steam, only the second touches the lamp.
        BlockPos first = new BlockPos(1, 1, 1);
        BlockPos second = first.east();
        BlockPos lamp = second.east();
        helper.setBlock(first, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(second, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(lamp, ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.runAfterDelay(2, () -> turbine(helper, first).insert(Direction.UP, FluidType.STEAM, 2000.0, false));
        helper.runAfterDelay(30, () -> {
            double power = lamp(helper, lamp).powerFraction();
            helper.assertTrue(power >= 0.999, "Power should pass from one turbine through the next (" + format(power) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 100)
    public void condenserDoublesTheTurbinePower(GameTestHelper helper) {
        // Two turbines powering a lamp each from the same 300 °C steam: one sits on a condenser with cooling
        // water, the other blows its exhaust into the air and needs twice the steam for the same power.
        BlockPos condensing = new BlockPos(1, 2, 1);
        BlockPos condenserPos = condensing.below();
        BlockPos venting = new BlockPos(4, 1, 3);
        helper.setBlock(condenserPos, ModBlocks.CONDENSER.defaultBlockState());
        helper.setBlock(condensing, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(condensing.east(), ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.setBlock(venting, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(venting.east(), ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            turbine(helper, condensing).insert(Direction.UP, FluidType.STEAM, 1000.0, 300.0, false);
            turbine(helper, venting).insert(Direction.UP, FluidType.STEAM, 1000.0, 300.0, false);
            // The condenser faces north, so its back (cooling water in) is the south face.
            condenser(helper, condenserPos).insert(Direction.SOUTH, FluidType.WATER, 1000.0, false);
        });
        helper.runAfterDelay(60, () -> {
            SteamTurbineBlockEntity a = turbine(helper, condensing);
            SteamTurbineBlockEntity b = turbine(helper, venting);
            helper.assertTrue(!a.isVenting() && a.exhaustPressure() < 0.1,
                    "The turbine on the condenser should exhaust into its vacuum (" + format(a.exhaustPressure()) + " bar)");
            helper.assertTrue(b.isVenting(), "A turbine with nothing below should blow its exhaust into the air");
            double ratio = b.lastSteamUse() / Math.max(1.0e-9, a.lastSteamUse());
            helper.assertTrue(ratio > 1.8 && ratio < 2.2, "Venting should need about twice the steam for the same power (" + format(ratio) + "x)");
            helper.assertTrue(condenser(helper, condenserPos).condensate() > 0.0, "The condenser should turn the exhaust back into water");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void turbineSealsLeakALittleSteam(GameTestHelper helper) {
        // A turbine on a condenser with cooling water, powering a lamp: a small share of the steam it uses leaks at
        // its shaft seals, and the rest goes on into the condenser without venting.
        BlockPos turbinePos = new BlockPos(1, 2, 1);
        BlockPos condenserPos = turbinePos.below();
        helper.setBlock(condenserPos, ModBlocks.CONDENSER.defaultBlockState());
        helper.setBlock(turbinePos, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(turbinePos.east(), ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            turbine(helper, turbinePos).insert(Direction.UP, FluidType.STEAM, 100.0, 300.0, false);
            // The condenser faces north, so its back (cooling water in) is the south face.
            condenser(helper, condenserPos).insert(Direction.SOUTH, FluidType.WATER, 1000.0, false);
        });
        helper.runAfterDelay(40, () -> {
            SteamTurbineBlockEntity turbine = turbine(helper, turbinePos);
            double expected = turbine.lastSteamUse() * NuclearConfig.get().turbineSteamLoss;
            helper.assertTrue(turbine.lastSteamUse() > 0.0, "The turbine should be using steam");
            helper.assertTrue(Math.abs(turbine.lastLeak() - expected) < 1.0e-9,
                    "The seals should leak " + format(expected) + " mB/t (got " + format(turbine.lastLeak()) + ")");
            helper.assertTrue(!turbine.isVenting(), "The rest should go into the condenser, not the air");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void condenserTurnsSteamIntoWater(GameTestHelper helper) {
        // A condenser facing north (cooling water in at the south, out at the north) with nothing around it.
        BlockPos pos = new BlockPos(2, 1, 2);
        helper.setBlock(pos, ModBlocks.CONDENSER.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            CondenserBlockEntity condenser = condenser(helper, pos);
            helper.assertTrue(condenser.insert(Direction.NORTH, FluidType.WATER, 100.0, true) == 0.0, "Cooling water only goes in at the back");
            helper.assertTrue(condenser.insert(Direction.EAST, FluidType.STEAM, 100.0, true) == 0.0, "Steam only goes in at the top");
            condenser.insert(Direction.UP, FluidType.STEAM, 200.0, 40.0, false);
            condenser.insert(Direction.SOUTH, FluidType.WATER, 1000.0, false);
        });
        helper.runAfterDelay(30, () -> {
            CondenserBlockEntity condenser = condenser(helper, pos);
            NuclearConfig config = NuclearConfig.get();
            double water = condenser.extract(Direction.DOWN, FluidType.WATER, 5000.0, false, true);
            double cooling = condenser.extract(Direction.NORTH, FluidType.WATER, 5000.0, false, true);
            double warm = condenser.temperature(Direction.NORTH, FluidType.WATER);
            helper.assertTrue(Math.abs(water - 200.0 / config.steamPerWater) < 0.01, "All the steam should come back as water (" + format(water) + ")");
            helper.assertTrue(Math.abs(cooling - 200.0 * config.condenserCoolingWater) < 0.01,
                    "The cooling water should come out of the front (" + format(cooling) + ")");
            helper.assertTrue(warm > 20.0, "The cooling water should come out warmer (" + format(warm) + " °C)");
            helper.assertTrue(condenser.fillLevel(Direction.UP) < 0.001, "No steam should be left");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void fullCondenserBacksUpTheTurbine(GameTestHelper helper) {
        // A turbine powering a lamp, on a condenser that has no cooling water and is already full of steam.
        BlockPos turbinePos = new BlockPos(1, 2, 1);
        BlockPos condenserPos = turbinePos.below();
        BlockPos lamp = turbinePos.east();
        helper.setBlock(condenserPos, ModBlocks.CONDENSER.defaultBlockState());
        helper.setBlock(turbinePos, ModBlocks.STEAM_TURBINE.defaultBlockState());
        helper.setBlock(lamp, ModBlocks.ELECTRIC_LAMP.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            condenser(helper, condenserPos).insert(Direction.UP, FluidType.STEAM, 1000.0, 40.0, false);
            turbine(helper, turbinePos).insert(Direction.UP, FluidType.STEAM, 1000.0, 300.0, false);
        });
        helper.runAfterDelay(30, () -> {
            SteamTurbineBlockEntity turbine = turbine(helper, turbinePos);
            helper.assertTrue(turbine.exhaustPressure() > 0.9,
                    "The backed-up exhaust should rise to the open air's pressure (" + format(turbine.exhaustPressure()) + " bar)");
            double power = lamp(helper, lamp).powerFraction();
            helper.assertTrue(power >= 0.999, "At half power per mB the turbine should still light the lamp (" + format(power) + ")");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 80)
    public void dumpValveOpensAboveItsSettingIntoTheCondenser(GameTestHelper helper) {
        // Steam pipe on top of the valve (facing north); a pipe from its back (south) down into a condenser with
        // cooling water. 400 °C steam, valve set to 380 °C.
        BlockPos valvePos = new BlockPos(2, 2, 2);
        BlockPos pipe = valvePos.above();
        BlockPos exhaustPipe = valvePos.south();
        BlockPos condenserPos = exhaustPipe.below();
        helper.setBlock(condenserPos, ModBlocks.CONDENSER.defaultBlockState());
        helper.setBlock(valvePos, ModBlocks.STEAM_DUMP_VALVE.defaultBlockState());
        helper.setBlock(pipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        helper.setBlock(exhaustPipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        recompute(helper, pipe);
        recompute(helper, exhaustPipe);
        helper.runAfterDelay(2, () -> {
            dumpValve(helper, valvePos).setSetting(380.0);
            condenser(helper, condenserPos).insert(Direction.SOUTH, FluidType.WATER, 1000.0, false);
            network(helper, pipe).insert(Direction.UP, FluidType.STEAM, 200.0, 400.0, false);
        });
        helper.runAfterDelay(15, () -> {
            SteamDumpValveBlockEntity valve = dumpValve(helper, valvePos);
            helper.assertTrue(valve.opening() > 0.2, "Steam 20 °C over the setting should open the valve (" + format(valve.opening()) + ")");
            helper.assertTrue(helper.getBlockState(valvePos).getValue(SteamDumpValveBlock.OPENING) > 0, "The gauge should show it open");
        });
        helper.runAfterDelay(60, () -> {
            double left = network(helper, pipe).amount();
            double water = condenser(helper, condenserPos).extract(Direction.DOWN, FluidType.WATER, 5000.0, false, true);
            helper.assertTrue(left < 1.0, "The valve should have dumped the steam (" + format(left) + " mB left)");
            helper.assertTrue(water > 50.0, "The dumped steam should come back as water in the condenser (" + format(water) + " mB)");
            helper.assertTrue(!dumpValve(helper, valvePos).dumpsIntoTheAir(), "Piped to a condenser, nothing should go into the air");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 80)
    public void dumpValveFollowsItsMode(GameTestHelper helper) {
        // Nothing behind the valve: once it opens, the steam goes into the air.
        BlockPos valvePos = new BlockPos(2, 1, 2);
        BlockPos pipe = valvePos.above();
        helper.setBlock(valvePos, ModBlocks.STEAM_DUMP_VALVE.defaultBlockState());
        helper.setBlock(pipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        recompute(helper, pipe);
        helper.runAfterDelay(2, () -> {
            dumpValve(helper, valvePos).setSetting(500.0);
            network(helper, pipe).insert(Direction.UP, FluidType.STEAM, 200.0, 400.0, false);
        });
        helper.runAfterDelay(25, () -> {
            SteamDumpValveBlockEntity valve = dumpValve(helper, valvePos);
            helper.assertTrue(valve.opening() == 0.0, "Steam below the setting should keep it shut (" + format(valve.opening()) + ")");
            helper.assertTrue(network(helper, pipe).amount() > 199.0, "A shut valve should take no steam (" + format(network(helper, pipe).amount()) + ")");
            valve.setMode(SteamDumpValveBlockEntity.Mode.OPEN);
        });
        helper.runAfterDelay(70, () -> {
            SteamDumpValveBlockEntity valve = dumpValve(helper, valvePos);
            helper.assertTrue(valve.dumpsIntoTheAir(), "With nothing behind it, the valve should dump into the air");
            helper.assertTrue(network(helper, pipe).amount() < 1.0, "Open, the valve should dump the steam (" + format(network(helper, pipe).amount()) + " mB left)");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 60)
    public void backedUpDumpValveSlowsDown(GameTestHelper helper) {
        // The condenser at the end of the exhaust pipe has no cooling water, and it and the pipe are already full of
        // steam: the valve's flow falls to nothing.
        BlockPos valvePos = new BlockPos(2, 2, 2);
        BlockPos pipe = valvePos.above();
        BlockPos exhaustPipe = valvePos.south();
        BlockPos condenserPos = exhaustPipe.below();
        helper.setBlock(condenserPos, ModBlocks.CONDENSER.defaultBlockState());
        helper.setBlock(valvePos, ModBlocks.STEAM_DUMP_VALVE.defaultBlockState());
        helper.setBlock(pipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        helper.setBlock(exhaustPipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        recompute(helper, pipe);
        recompute(helper, exhaustPipe);
        helper.runAfterDelay(2, () -> {
            dumpValve(helper, valvePos).setMode(SteamDumpValveBlockEntity.Mode.OPEN);
            condenser(helper, condenserPos).insert(Direction.UP, FluidType.STEAM, 1000.0, 40.0, false);
            network(helper, exhaustPipe).insert(Direction.UP, FluidType.STEAM, 1000.0, 40.0, false);
            network(helper, pipe).insert(Direction.UP, FluidType.STEAM, 200.0, 400.0, false);
        });
        helper.runAfterDelay(40, () -> {
            SteamDumpValveBlockEntity valve = dumpValve(helper, valvePos);
            helper.assertTrue(valve.flowFactor() < 0.01, "A full exhaust should stop the flow (" + format(valve.flowFactor()) + ")");
            helper.assertTrue(valve.exhaustPressure() > 0.9, "The back-pressure should rise to the open air's (" + format(valve.exhaustPressure()) + " bar)");
            helper.assertTrue(!valve.dumpsIntoTheAir(), "A backed-up valve should hold the steam back, not blow it into the air");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 160)
    public void outletPoursAndTakesBackItsWater(GameTestHelper helper) {
        // A pipe with some water in it, and an outlet facing open air.
        BlockPos pipe = new BlockPos(1, 1, 2);
        BlockPos outletPos = pipe.east();
        BlockPos front = outletPos.east();
        helper.setBlock(outletPos, ModBlocks.WATER_OUTLET.defaultBlockState().setValue(WaterOutletBlock.FACING, Direction.EAST));
        helper.setBlock(pipe, ModBlocks.FLUID_PIPE.defaultBlockState());
        recompute(helper, pipe);
        helper.runAfterDelay(2, () -> network(helper, pipe).insert(Direction.UP, FluidType.WATER, 200.0, false));
        helper.runAfterDelay(8, () -> {
            double left = network(helper, pipe).amount();
            helper.assertTrue(left < 1.0, "The outlet should drain the pipe (" + format(left) + " left)");
            helper.assertTrue(isWaterSource(helper, front), "The outlet should pour out a water block in front of it");
        });
        helper.runAfterDelay(120, () -> {
            helper.assertTrue(!isWaterSource(helper, front), "Once the water stopped, the outlet should take its water block back");
            helper.succeed();
        });
    }

    @GameTest(maxTicks = 40)
    public void blockedOutletLetsNothingOut(GameTestHelper helper) {
        BlockPos outletPos = new BlockPos(2, 1, 2);
        BlockPos front = outletPos.east();
        helper.setBlock(outletPos, ModBlocks.WATER_OUTLET.defaultBlockState().setValue(WaterOutletBlock.FACING, Direction.EAST));
        helper.setBlock(front, Blocks.STONE.defaultBlockState());
        helper.runAfterDelay(2, () -> {
            WaterOutletBlockEntity outlet = outlet(helper, outletPos);
            double blocked = outlet.insert(Direction.WEST, FluidType.WATER, 50.0, false);
            helper.assertTrue(blocked == 0.0, "An outlet facing stone should take no water (took " + format(blocked) + ")");
            helper.setBlock(front, Blocks.AIR.defaultBlockState());
            double open = outlet.insert(Direction.WEST, FluidType.WATER, 50.0, false);
            helper.assertTrue(Math.abs(open - 50.0) < 1.0e-6, "An outlet facing air should take the water (took " + format(open) + ")");
            double coolant = outlet.insert(Direction.WEST, FluidType.COOLANT, 50.0, false);
            helper.assertTrue(coolant == 0.0, "An outlet should never take coolant (took " + format(coolant) + ")");
            helper.succeed();
        });
    }

    // ---------------------------------------------------------------- helpers

    private static EnrichmentCentrifugeBlockEntity centrifuge(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof EnrichmentCentrifugeBlockEntity centrifuge) return centrifuge;
        throw helper.assertionException("No enrichment centrifuge at " + relative.toShortString());
    }

    /**
     * Puts a rod with just a sliver of fuel left into a fuel channel.
     */
    private static void setNearlySpent(GameTestHelper helper, BlockPos channelPos, Item rod) {
        if (!(blockEntity(helper, channelPos) instanceof FuelChannelBlockEntity channel)) {
            throw helper.assertionException("No fuel channel at " + channelPos.toShortString());
        }
        ItemStack stack = new ItemStack(rod);
        FuelRods.setUsedEnergy(stack, FuelRods.energy(FuelRods.tierOf(stack)) * (1.0 - 2.0e-5));
        channel.takeRod();
        channel.setRod(stack);
    }

    private static ItemStack rodIn(GameTestHelper helper, BlockPos channelPos) {
        if (blockEntity(helper, channelPos) instanceof FuelChannelBlockEntity channel) return channel.getRod();
        throw helper.assertionException("No fuel channel at " + channelPos.toShortString());
    }

    /**
     * The check valve of {@link #buildValveLine}.
     */
    private static CheckValveBlockEntity checkValve(GameTestHelper helper) {
        if (blockEntity(helper, new BlockPos(4, 1, 3)) instanceof CheckValveBlockEntity valve) return valve;
        throw helper.assertionException("No check valve");
    }

    private static ExpansionTankBlockEntity tank(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof ExpansionTankBlockEntity tank) return tank;
        throw helper.assertionException("No expansion tank at " + relative.toShortString());
    }

    private static SteamDumpValveBlockEntity dumpValve(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof SteamDumpValveBlockEntity valve) return valve;
        throw helper.assertionException("No steam dump valve at " + relative.toShortString());
    }

    private static CondenserBlockEntity condenser(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof CondenserBlockEntity condenser) return condenser;
        throw helper.assertionException("No condenser at " + relative.toShortString());
    }

    private static WaterOutletBlockEntity outlet(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof WaterOutletBlockEntity outlet) return outlet;
        throw helper.assertionException("No water outlet at " + relative.toShortString());
    }

    private static boolean isWaterSource(GameTestHelper helper, BlockPos relative) {
        FluidState fluid = helper.getLevel().getFluidState(helper.absolutePos(relative));
        return fluid.is(FluidTags.WATER) && fluid.isSource();
    }

    private static SteamTurbineBlockEntity turbine(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof SteamTurbineBlockEntity turbine) return turbine;
        throw helper.assertionException("No steam turbine at " + relative.toShortString());
    }

    private static WaterPumpBlockEntity waterPump(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof WaterPumpBlockEntity pump) return pump;
        throw helper.assertionException("No water pump at " + relative.toShortString());
    }

    private static ElectricLampBlockEntity lamp(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof ElectricLampBlockEntity lamp) return lamp;
        throw helper.assertionException("No lamp at " + relative.toShortString());
    }

    private static BlockState batteryFacing(Direction front) {
        return ModBlocks.BATTERY_BANK.defaultBlockState().setValue(BatteryBankBlock.FACING, front);
    }

    private static BatteryBankBlockEntity battery(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof BatteryBankBlockEntity battery) return battery;
        throw helper.assertionException("No battery bank at " + relative.toShortString());
    }

    private static void recompute(GameTestHelper helper, BlockPos pipe) {
        BlockPos absolute = helper.absolutePos(pipe);
        helper.getLevel().setBlock(absolute, FluidPipeBlock.computeState(helper.getLevel(), absolute, helper.getLevel().getBlockState(absolute)), 3);
    }

    private static HeatExchangerBlockEntity exchanger(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof HeatExchangerBlockEntity hx) return hx;
        throw helper.assertionException("No heat exchanger at " + relative.toShortString());
    }

    private static CirculationPumpBlockEntity pump(GameTestHelper helper, BlockPos relative) {
        if (blockEntity(helper, relative) instanceof CirculationPumpBlockEntity pump) return pump;
        throw helper.assertionException("No circulation pump at " + relative.toShortString());
    }

    /**
     * Supply pipes, a check valve at (4,1,3) flowing east, then outlet pipes.
     */
    private static void buildValveLine(GameTestHelper helper, List<BlockPos> supply, List<BlockPos> outlet) {
        for (BlockPos pos : supply) helper.setBlock(pos, ModBlocks.FLUID_PIPE.defaultBlockState());
        helper.setBlock(new BlockPos(4, 1, 3), ModBlocks.CHECK_VALVE.defaultBlockState().setValue(CheckValveBlock.FACING, Direction.EAST));
        for (BlockPos pos : outlet) helper.setBlock(pos, ModBlocks.FLUID_PIPE.defaultBlockState());
        for (List<BlockPos> line : List.of(supply, outlet)) {
            for (BlockPos pos : line) {
                BlockPos absolute = helper.absolutePos(pos);
                BlockState state = helper.getLevel().getBlockState(absolute);
                helper.getLevel().setBlock(absolute, FluidPipeBlock.computeState(helper.getLevel(), absolute, state), 3);
            }
        }
    }

    private static PipeNetwork network(GameTestHelper helper, BlockPos relative) {
        PipeNetwork network = PipeNetworks.of(helper.getLevel()).networkAt(helper.absolutePos(relative));
        if (network == null) throw helper.assertionException("No pipe network at " + relative.toShortString());
        return network;
    }

    private static void buildReactor(GameTestHelper helper) {
        BlockState casing = ModBlocks.REACTOR_CASING.defaultBlockState();
        for (int x = 1; x <= 5; x++) {
            for (int y = 1; y <= 5; y++) {
                for (int z = 1; z <= 5; z++) {
                    boolean shell = x == 1 || x == 5 || y == 1 || y == 5 || z == 1 || z == 5;
                    helper.setBlock(new BlockPos(x, y, z), shell ? casing : Blocks.AIR.defaultBlockState());
                }
            }
        }
        helper.setBlock(CONTROLLER, ModBlocks.REACTOR_CONTROLLER.defaultBlockState());
        helper.setBlock(new BlockPos(1, 3, 3), ModBlocks.REACTOR_PORT.defaultBlockState());
        helper.setBlock(new BlockPos(5, 3, 3), ModBlocks.REACTOR_PORT.defaultBlockState());
        for (BlockPos pos : CONTROL) {
            helper.setBlock(pos, ModBlocks.CONTROL_ROD_CHANNEL.defaultBlockState().setValue(ControlRodChannelBlock.HAS_ROD, true));
        }
        for (BlockPos pos : FUEL) {
            helper.setBlock(pos, ModBlocks.FUEL_CHANNEL.defaultBlockState());
            if (blockEntity(helper, pos) instanceof FuelChannelBlockEntity channel) {
                channel.setRod(new ItemStack(ModItems.REDSTONE_FUEL_ROD));
            } else {
                throw helper.assertionException("Fuel channel at " + pos.toShortString() + " has no block entity");
            }
        }
    }

    /**
     * Clears the SCRAM (the reactor starts shut down) and sets the rods.
     */
    private static void start(GameTestHelper helper, double insertion) {
        ReactorControllerBlockEntity controller = controller(helper);
        helper.assertTrue(controller.isFormed(), "Reactor did not form: " + controller.status().getString());
        String error = controller.reset(helper.getLevel());
        helper.assertTrue(error == null, "Could not start the reactor: " + error);
        controller.setInsertion(insertion);
    }

    private static ReactorControllerBlockEntity controller(GameTestHelper helper) {
        if (blockEntity(helper, CONTROLLER) instanceof ReactorControllerBlockEntity controller) return controller;
        throw helper.assertionException("No reactor controller at " + CONTROLLER.toShortString());
    }

    private static BlockEntity blockEntity(GameTestHelper helper, BlockPos relative) {
        return helper.getLevel().getBlockEntity(helper.absolutePos(relative));
    }

    private static String format(double value) {
        return String.format(Locale.ROOT, "%.3f", value);
    }
}
